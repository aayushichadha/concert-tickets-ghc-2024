# crypt

**This is a maintained fork of the [fork](https://github.com/bketelsen/crypt) of the abandoned [original](https://github.com/xordataexchange/crypt)**

This fork serves the purposes of [Viper](https://github.com/spf13/viper) providing a way to access remote key-value stores.


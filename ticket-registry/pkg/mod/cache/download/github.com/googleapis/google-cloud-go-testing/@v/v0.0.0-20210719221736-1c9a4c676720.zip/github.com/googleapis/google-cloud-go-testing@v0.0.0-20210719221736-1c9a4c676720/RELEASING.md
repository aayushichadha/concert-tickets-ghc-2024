# Releasing

This repository does not have releases. Users should rely on semver
pseudo-versions in their go.mod files.

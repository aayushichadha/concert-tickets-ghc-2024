This directory contains the user data that is used to initialize the
nodes that are started by CloudFormation.

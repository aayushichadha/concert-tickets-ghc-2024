# Examples

* chat is a command line chat program using listen/notify.
* todo is a command line todo list that demonstrates basic CRUD actions.
* url_shortener contains a simple example of using pgx in a web context.
* [Tern](https://github.com/jackc/tern) is a migration tool that uses pgx.
* [The Pithy Reader](https://github.com/jackc/tpr) is a RSS aggregator that uses pgx.
